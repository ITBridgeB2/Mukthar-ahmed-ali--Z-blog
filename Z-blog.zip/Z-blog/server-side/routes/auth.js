const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const authenticateToken = require('../middleware/authmiddleware');
const router = express.Router();

// Register
router.post('/register', async (req, res) => {
  const { first_name, last_name, username, password, email, phone_number, dob } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (results.length > 0) return res.status(400).json({ message: 'Username exists' });

    db.query(
      'INSERT INTO users (first_name, last_name, username, password, email, phone_number, dob) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [first_name, last_name, username, hashedPassword, email, phone_number, dob],
      err => {
        if (err) return res.status(500).json({ message: 'DB error' });
        res.status(201).json({ message: 'User registered' });
      }
    );
  });
});

// Login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (results.length === 0) return res.status(400).json({ message: 'User not found' });

    const user = results[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ message: 'Invalid password' });

    const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  });
});

// Profile
router.get('/profile', authenticateToken, (req, res) => {
  db.query('SELECT id, first_name, last_name, username, email, phone_number, dob FROM users WHERE id = ?', [req.user.id], (err, results) => {
    if (err || results.length === 0) return res.status(404).json({ message: 'User not found' });
    res.json(results[0]);
  });
});

module.exports = router;
