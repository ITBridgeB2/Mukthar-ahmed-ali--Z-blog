// routes/posts.js
const express = require('express');
const db = require('../db');
const authenticateToken = require('../middleware/authmiddleware');
const router = express.Router();

// — Create a post (auth required)
router.post('/', authenticateToken, (req, res) => {
  const userId = req.user.id;
  const { title, content } = req.body;
  db.query(
    'INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)',
    [userId, title, content],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'DB error', err });
      res.status(201).json({ id: result.insertId, message: 'Post created' });
    }
  );
});

// — Get all posts (public)
router.get('/', (req, res) => {
  db.query(
    `SELECT p.id, p.title, p.content, p.created_at, u.username AS author
     FROM posts p
     JOIN users u ON p.user_id = u.id
     ORDER BY p.created_at DESC`,
    (err, results) => {
      if (err) return res.status(500).json({ message: 'DB error', err });
      res.json(results);
    }
  );
});

// — Get single post by id (public)
router.get('/:id', (req, res) => {
  db.query(
    `SELECT p.id, p.title, p.content, p.created_at, u.username AS author
     FROM posts p
     JOIN users u ON p.user_id = u.id
     WHERE p.id = ?`,
    [req.params.id],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'DB error', err });
      if (!results.length) return res.status(404).json({ message: 'Post not found' });
      res.json(results[0]);
    }
  );
});

// — Get posts by a specific user (auth or public)
router.get('/user/:userId', (req, res) => {
  db.query(
    `SELECT id, title, content, created_at
     FROM posts
     WHERE user_id = ?
     ORDER BY created_at DESC`,
    [req.params.userId],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'DB error', err });
      res.json(results);
    }
  );
});

// — Update a post (auth required, only owner)
router.put('/:id', authenticateToken, (req, res) => {
  const userId = req.user.id;
  const postId = req.params.id;
  const { title, content } = req.body;

  // Verify ownership
  db.query('SELECT user_id FROM posts WHERE id = ?', [postId], (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', err });
    if (!rows.length) return res.status(404).json({ message: 'Post not found' });
    if (rows[0].user_id !== userId) return res.status(403).json({ message: 'Not allowed' });

    // Perform update
    db.query(
      'UPDATE posts SET title = ?, content = ? WHERE id = ?',
      [title, content, postId],
      (err) => {
        if (err) return res.status(500).json({ message: 'DB error', err });
        res.json({ message: 'Post updated' });
      }
    );
  });
});

// — Delete a post (auth required, only owner)
router.delete('/:id', authenticateToken, (req, res) => {
  const userId = req.user.id;
  const postId = req.params.id;

  // Verify ownership
  db.query('SELECT user_id FROM posts WHERE id = ?', [postId], (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', err });
    if (!rows.length) return res.status(404).json({ message: 'Post not found' });
    if (rows[0].user_id !== userId) return res.status(403).json({ message: 'Not allowed' });

    // Perform delete
    db.query('DELETE FROM posts WHERE id = ?', [postId], (err) => {
      if (err) return res.status(500).json({ message: 'DB error', err });
      res.json({ message: 'Post deleted' });
    });
  });
});

module.exports = router;
